from langchain_mistralai.chat_models import ChatMistralAI

llm = ChatMistralAI(temperature=0)